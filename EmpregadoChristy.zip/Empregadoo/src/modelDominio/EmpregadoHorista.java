/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelDominio;

import java.util.logging.Logger;

/**
 *
 * @author aluno
 */
public class EmpregadoHorista extends Empregado {

    private double valorHoras;
    private double horas;

    public EmpregadoHorista(double valorHoras, double horas, String nome, String sobrenome) {
        super(nome, sobrenome);
        this.valorHoras = valorHoras;
        this.horas = horas;
    }

    public double getValorHoras() {
        return valorHoras;
    }

    public void setValorHoras(double valorHoras) {
        this.valorHoras = valorHoras;
    }

    public double getHoras() {
        return horas;
    }

    public void setHoras(double horas) {
        this.horas = horas;
    }

    @Override
    public double calculaSalario() {
        return valorHoras * horas;
    }

}
