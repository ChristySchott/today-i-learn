
package modelDominio;

/**
 *
 * @author aluno
 */
public class EmpregadoComissionadoFixo extends EmpregadoComissionado{
    private double salarioFixo;

    public EmpregadoComissionadoFixo(double salarioFixo, double vendasBrutas, double comissao, String nome, String sobrenome) {
        super(vendasBrutas, comissao, nome, sobrenome);
        this.salarioFixo = salarioFixo;
    }

    public double getSalarioFixo() {
        return salarioFixo;
    }

    public void setSalarioFixo(double salarioFixo) {
        this.salarioFixo = salarioFixo;
    }

    @Override
    public double calculaSalario() {
        return super.calculaSalario() + salarioFixo; 
    }
    
    
}
