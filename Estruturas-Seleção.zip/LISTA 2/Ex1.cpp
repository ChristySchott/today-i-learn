#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	int a,b;

	printf("Informe um n�mero: ");
	scanf("%d",&a);
	printf("Informe um n�mero: ");
	scanf("%d",&b);
	
	if (a==b){
		printf("Os n�meros s�o iguais.");
	} else {
		if (a>b) {
				printf("O n�mero %d � maior!",a);
		} else if (b>a){
				printf("O n�mero %d � maior!",b);
		}
	}

}
