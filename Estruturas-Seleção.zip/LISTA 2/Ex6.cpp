#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	int senha;
	printf("Informe a senha: ");
	scanf("%d",&senha);
	
	if (senha==1234){
		printf("\nACESSO PERMITIDO");
	} else {
		printf("\nACESSO NEGADO");
	} 

}
