#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	int sexo,idade;

	printf("1- Masculino \n2- Feminino \nInforme o sexo: ");
	scanf("%d",&sexo);
	printf("\nInforme a idade: ");
	scanf("%d",&idade);
	
	if (sexo == 2 && idade < 25){
		printf("ACEITA!");
	} else {
		printf("N�O ACEITA!");
	}

}
