#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	int a;
	printf("Informe um n�mero: ");
	scanf("%d",&a);
	
	if (a > 20){
		printf("O n�mero � maior que 20.");
	} else if (a < 20){
		printf("O n�mero � menor que 20.");
	} else {
		printf("O n�mero � igual a 20.");
	} 

}
