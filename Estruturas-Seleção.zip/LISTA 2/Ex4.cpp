#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	int an,at;

	printf("Informe o ano de nascimento: ");
	scanf("%d",&an);
	printf("Informe o ano atual: ");
	scanf("%d",&at);
	
	if (an < at){
		printf("\nIdade: %d",at-an);
	} else {
		printf("\nAno de nascimento inv�lido.");
	}

}
