#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	float a,b,c;
	
	printf("Informe tr�s valores: ");
	scanf("%f %f %f",&a, &b, &c);
	
	if (a>0){
			printf ("Raiz quadrada: %0.2f", sqrt(a));
	} else {
			printf ("Quadrado do n�mero: %0.2f", a*a);
	} 	
	
	if (b>10 && b<100){
		printf ("\nN�mero est� entre 10 e 100 � intervalo permitido.");
	} 
	
	if (c<b){
			printf ("\nA diferen�a �: %0.2f", (b-c));
	} else {
			printf ("\nTerceiro n�mero adicionado de um: %0.2f", c+1);
	} 
	


}
