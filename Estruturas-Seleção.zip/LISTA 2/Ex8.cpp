#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	int a,b,c,menor;
	menor=0;
	
	printf("Informe tr�s valores: ");
	scanf("%d %d %d",&a, &b, &c);

	if (a<b && a<c){
		menor = a;
	} else if (b<a && b<c){
		menor = b;
	} else if (c<a && c<b){
		menor = c;
	}
	
	printf ("O menor n�mero �: %d", menor);
	
	if (menor > 100){
		printf ("\nO menor n�mero � maior que 100");
	}
	

}
