#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	float sexo,altura,ideal;

	printf("1- Masculino \n2- Feminino \nInforme o sexo: ");
	scanf("%f",&sexo);
	printf("\nInforme a altura: ");
	scanf("%f",&altura);
	
	if (sexo == 1){
		ideal = (72.7*altura)-58;
		printf("Peso ideal: %0.2f",ideal);
	} else if (sexo ==2) {
		ideal = (62.1*altura)-44.7;
		printf("Peso ideal: %0.2f",ideal);
	} else {
		printf("Sexo inv�lido.");
	}
	

}
