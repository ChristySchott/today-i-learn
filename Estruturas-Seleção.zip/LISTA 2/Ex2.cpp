#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	int a;

	printf("Informe um n�mero: ");
	scanf("%d",&a);
	
	if (a % 2==0){
		printf("\nO n�mero � divis�vel por 2.");
	} if (a % 5==0){
		printf("\nO n�mero � divis�vel por 5.");
	} if (a % 10 == 0){
		printf("\nO n�mero � divis�vel por 10.");
	} else {
		printf("O n�mero n�o � divis�vel por 2, 5 ou 10.");
	}

}
