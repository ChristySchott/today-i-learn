#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	float a,valorCredito;
	printf("Informe o saldo m�dio: ");
	scanf("%f",&a);
	
	if (a <= 200){
		valorCredito = 0;
		printf("Saldo m�dio: %0.2f \nValor do cr�dito: %0.2f",a,valorCredito);
	} if (a >= 201 && a <=400){
		valorCredito = a*0.20;
		printf("Saldo m�dio: %0.2f \nValor do cr�dito: %0.2f",a,valorCredito);
	} if (a >= 401 && a <=600){
		valorCredito = a*0.30;
		printf("Saldo m�dio: %0.2f \nValor do cr�dito: %0.2f",a,valorCredito);
	} if (a >= 601){
		valorCredito = a*0.40;
		printf("Saldo m�dio: %0.2f \nValor do cr�dito: %0.2f",a,valorCredito);
	} 
}
