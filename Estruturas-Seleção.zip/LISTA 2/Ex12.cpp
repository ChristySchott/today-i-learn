#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	float ano,preco,imposto;

	printf("Informe o ano do carro: ");
	scanf("%f",&ano);
	printf("\nInforme o pre�o de tabela: ");
	scanf("%f",&preco);
	
	if (ano <=1990){
		imposto = preco*0.1;
		printf("Imposto a ser pago: %0.2f",imposto);
	} else {
		imposto = preco*0.15;
		printf("Imposto a ser pago: %0.2f",imposto);
	}
	

}
