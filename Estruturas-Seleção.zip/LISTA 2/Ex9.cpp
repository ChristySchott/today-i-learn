#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <locale.h>

main ()	{
	setlocale(LC_ALL,"Portuguese");
	int a,b,c;
	
	printf("Informe os tr�s lados do tri�ngulo: ");
	scanf("%d %d %d",&a, &b, &c);

	if (a==b && a==c){
			printf ("O tri�ngulo � equil�tero");
	} else if (a==b & b!=c){
				printf ("O tri�ngulo � is�sceles");
	} else if (c!=a && a!=b){
					printf ("O tri�ngulo � escaleno");
	}


}
